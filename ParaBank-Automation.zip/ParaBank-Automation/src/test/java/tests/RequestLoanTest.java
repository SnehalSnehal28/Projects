package tests;

import base.BaseTest;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.RequestLoanPage;

public class RequestLoanTest extends BaseTest {

    @Test
    public void verifyLoanRequest() throws InterruptedException {

        // Step 1: Login
        LoginPage login = new LoginPage(driver);
        login.enterUsername("riddhi123"); 
        login.enterPassword("Riddhi@123");          
        login.clickLogin();
        Thread.sleep(2000);

        //  Step 2: Go to Request Loan page
        driver.findElement(By.linkText("Request Loan")).click();
        Thread.sleep(1000);

        //  Step 3: Fill loan details
        RequestLoanPage loan = new RequestLoanPage(driver);
        loan.enterLoanDetails("500", "100");
        Thread.sleep(1000);
        loan.clickApplyNow();
        
        //  Step 4: Verify result
        Thread.sleep(2000);
        Assert.assertTrue(loan.isLoanProcessed(), " Loan request was not processed successfully!");
        System.out.println("Loan Request Processed Successfully!");
    
        // Get result text (Approved or Denied)
        String result = driver.findElement(By.id("loanStatus")).getText();
        System.out.println("Loan Status: " + result);

        // Assert message
        Assert.assertTrue(result.contains("Approved") || result.contains("Denied"),
                "Loan status not found: " + result);
    }
    
}
