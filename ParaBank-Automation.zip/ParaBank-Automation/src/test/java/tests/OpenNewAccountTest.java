package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import base.BaseTest;
import pages.LoginPage;
import pages.OpenNewAccountPage;

public class OpenNewAccountTest extends BaseTest {

    @Test
    public void verifyOpenNewAccount() throws InterruptedException {
        // --- Step 1: Login ---
        LoginPage login = new LoginPage(driver);
        login.enterUsername("riddhi123");
        login.enterPassword("Riddhi@123");
        login.clickLogin();
        Thread.sleep(2000);

        // --- Step 2: Open New Account ---
        OpenNewAccountPage openAcc = new OpenNewAccountPage(driver);
        openAcc.clickOpenNewAccountLink();
        Thread.sleep(2000);

        openAcc.selectAccountType("SAVINGS");
        openAcc.selectFromAccount(0);
        openAcc.clickOpenNewAccountButton();
        Thread.sleep(2000);

        // --- Step 3: Verify ---
        boolean result = openAcc.isAccountOpened();
        Assert.assertTrue(result, " Account creation failed!");
        System.out.println("Account created successfully!");

        String accNo = openAcc.getNewAccountNumber();
        System.out.println(" New Account Number: " + accNo);
    }
}
