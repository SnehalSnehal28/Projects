package tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;
import base.BaseTest;
import pages.LoginPage;

public class UpdateContactInfoTest extends BaseTest {

    @Test
    public void updateContactInformation() throws InterruptedException {

    	 LoginPage login = new LoginPage(driver);
         login.enterUsername("riddhi123");
         login.enterPassword("Riddhi@123");
         login.clickLogin();
         Thread.sleep(2000);  // wait for dashboard to load
    	
    	//open update info link
    	
    	
        //  Click on "Update Contact Info"
        driver.findElement(By.linkText("Update Contact Info")).click();

        // Clear old info and enter new info
        driver.findElement(By.id("customer.address.street")).clear();
        driver.findElement(By.id("customer.address.street")).sendKeys("Near Lake View, City Road");

        driver.findElement(By.id("customer.address.city")).clear();
        driver.findElement(By.id("customer.address.city")).sendKeys("Ahmedabad");

        driver.findElement(By.id("customer.address.state")).clear();
        driver.findElement(By.id("customer.address.state")).sendKeys("Gujarat");

        driver.findElement(By.id("customer.address.zipCode")).clear();
        driver.findElement(By.id("customer.address.zipCode")).sendKeys("380015");

        driver.findElement(By.id("customer.phoneNumber")).clear();
        driver.findElement(By.id("customer.phoneNumber")).sendKeys("9876543210");

        //  Click Update Profile button
        driver.findElement(By.xpath("//input[@value='Update Profile']")).click();

        Thread.sleep(2000);
        
        //  Verify success message for update
        String successMsg = driver.findElement(By.xpath("//div[@id='rightPanel']//p")).getText();
        Assert.assertTrue(successMsg.contains("updated"), "Contact Info updated successfully!");
        
        //  Log out
        driver.findElement(By.linkText("Log Out")).click();
        Thread.sleep(2000);

        // Verify login page visible again
        boolean isLoginBoxVisible = driver.findElement(By.name("username")).isDisplayed();
        Assert.assertTrue(isLoginBoxVisible, "Logout successful — login page is displayed again!");

        //  Verify success message
       
    }
}
