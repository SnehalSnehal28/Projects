package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.AccountHistoryPage;
import pages.LoginPage;

public class AccountHistoryTest extends BaseTest {

    @Test
    public void verifyAccountHistory() throws InterruptedException {

        // Login first
        LoginPage login = new LoginPage(driver);
        login.enterUsername("riddhi123");  
        login.enterPassword("Riddhi@123");            
        login.clickLogin();

        //Wait a bit to ensure dashboard loads
        Thread.sleep(2000);

        // Click on any account link (e.g., first account number)
        driver.findElement(org.openqa.selenium.By.xpath("//a[contains(@href, 'activity.htm?id=')]")).click();
        Thread.sleep(3000); // wait for page load

        //  Verify transaction history table
        AccountHistoryPage accHistory = new AccountHistoryPage(driver);
        System.out.println(" Checking if transaction table is displayed...");
        Assert.assertTrue(accHistory.isTransactionTableDisplayed(), "Transaction history table not visible!");
    }
}
