package tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;
import base.BaseTest;
import pages.LoginPage;


public class LoginTest extends BaseTest {

    @Test
    public void verifyValidLogin() {
    	
    	// --- Register a new user first ---
       driver.findElement(By.linkText("Register")).click();
       RegisterTest register = new RegisterTest(driver);
       register.enterFirstName("Snehal");
       register.enterLastName("Solanki");
       register.enterAddress("Ahmedabad");
       register.enterCity("Ahmedabad");
       register.enterState("Gujarat");
       register.enterZipCode("380001");
       register.enterPhone("9999999999");
       register.enterSSN("12345");
       register.enterUsername("snehal123");
       register.enterPassword("Snehal@123");
       register.confirmPassword("Snehal@123");
       register.clickRegisterButton();
       
       //logout after registration
       driver.findElement(By.linkText("Log Out")).click();
        // --- Login ---
        
        LoginPage login = new LoginPage(driver);

        // enter your manually registered username & password
        login.enterUsername("riddhi123");   
        login.enterPassword("Riddhi@123");
        login.clickLogin();

        boolean result = login.isLoginSuccessful();
        Assert.assertTrue(result, "Login Failed - Accounts Overview not visible!");
        System.out.println("Login Successful - Accounts Overview page displayed.");
    }
}
