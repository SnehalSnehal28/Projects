package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import base.BaseTest;
import pages.LoginPage;
import pages.TransferFundsPage;

public class TransferFundsTest extends BaseTest {

    @Test
    public void verifyFundsTransfer() throws InterruptedException {
        // --- Step 1: Login ---
        LoginPage login = new LoginPage(driver);
        login.enterUsername("riddhi123");
        login.enterPassword("Riddhi@123");
        login.clickLogin();
        Thread.sleep(2000);

        // --- Step 2: Transfer Funds ---
        TransferFundsPage transfer = new TransferFundsPage(driver);
        transfer.clickTransferFundsLink();
        Thread.sleep(2000);

        transfer.enterAmount("100");
        transfer.clickTransferButton();
        Thread.sleep(2000);

        // --- Step 3: Verification ---
        boolean result = transfer.isTransferSuccessful();
        Assert.assertTrue(result, " Transfer failed or confirmation message not displayed!");
        System.out.println(" Fund Transfer Successful!");
    }
}
