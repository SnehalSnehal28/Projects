package tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;
import base.BaseTest;

public class ForgotPasswordTest extends BaseTest {

    @Test
    public void verifyForgotPassword() throws InterruptedException {

        // Step 1: Click on "Forgot login info?" link
        driver.findElement(By.linkText("Forgot login info?")).click();

        // Step 2: Fill form details
        driver.findElement(By.name("firstName")).sendKeys("Ridhhi");
        driver.findElement(By.name("lastName")).sendKeys("Solanki");
        driver.findElement(By.name("address.street")).sendKeys("City Road");
        driver.findElement(By.name("address.city")).sendKeys("Ahmedabad");
        driver.findElement(By.name("address.state")).sendKeys("Gujarat");
        driver.findElement(By.name("address.zipCode")).sendKeys("380015");
        driver.findElement(By.name("ssn")).sendKeys("12345");

        // Step 3: Click Find My Login Info button
        driver.findElement(By.xpath("//*[@id=\"lookupForm\"]/table/tbody/tr[8]/td[2]/input")).click();

		/*
		 * Thread.sleep(2000);
		 * 
		 * // Step 4: Verify success message String successText =
		 * driver.findElement(By.xpath("//div[@id='rightPanel']/p[1]")).getText();
		 * Assert.assertTrue(successText.
		 * contains("Your login information was located successfully."),
		 * "Forgot password process verified successfully!");
		 */
    }
}
