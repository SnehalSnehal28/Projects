package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import base.BaseTest;
import pages.LoginPage;
import pages.BillPayPage;

public class BillPayTest extends BaseTest {

    @Test
    public void verifyBillPayment() throws InterruptedException {
        // ---  Login ---
        LoginPage login = new LoginPage(driver);
        login.enterUsername("riddhi123");
        login.enterPassword("Riddhi@123");
        login.clickLogin();
        Thread.sleep(2000);

        // ---  Navigate to Bill Pay ---
        BillPayPage billPay = new BillPayPage(driver);
        billPay.clickBillPayLink();
        Thread.sleep(2000);

        // ---  Fill Payment Details ---
        billPay.fillPayeeDetails(
            "Snehal Solanki",
            "101 Shanti Nagar",
            "Ahmedabad",
            "Gujarat",
            "380001",
            "9999999999",
            "12345",
            "500"
        );

        billPay.clickSendPayment();
        Thread.sleep(2000);

        // --- Step 4: Verify Result ---
        boolean result = billPay.isPaymentSuccessful();
        Assert.assertTrue(result, " Bill payment failed!");
        System.out.println("Bill Payment completed successfully!");
    }
}
