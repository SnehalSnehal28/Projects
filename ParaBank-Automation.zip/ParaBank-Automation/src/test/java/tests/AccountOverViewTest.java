package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import base.BaseTest;

public class AccountOverViewTest extends BaseTest {

    @Test
    public void verifyAccountOverview() throws InterruptedException {
        //  Login
        driver.findElement(By.name("username")).sendKeys("riddhi123");
        driver.findElement(By.name("password")).sendKeys("Riddhi@123");
        driver.findElement(By.xpath("//input[@value='Log In']")).click();

        //  Verify Overview Page opened
        String pageTitle = driver.findElement(By.xpath("//h1")).getText();
        Assert.assertTrue(pageTitle.contains("Accounts Overview"), "Accounts Overview page not displayed!");

        //  Verify Account Number
        Thread.sleep(2000); 
        WebElement accNumber = driver.findElement(By.xpath("//table[@id='accountTable']//tr[1]/td[1]/a"));
        Assert.assertTrue(accNumber.isDisplayed(), "Account number not visible!");

        // Verify Balance
        WebElement balance = driver.findElement(By.xpath("//table[@id='accountTable']//tr[1]/td[2]"));
        Assert.assertTrue(balance.isDisplayed(), "Balance not visible!");

        //  Print account info
        System.out.println("Account Number: " + accNumber.getText());
        System.out.println("Balance: " + balance.getText());
    }
}
