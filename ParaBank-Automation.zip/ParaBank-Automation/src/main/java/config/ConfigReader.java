package config;

public class ConfigReader {

}
