package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RequestLoanPage {

    WebDriver driver;

    // Locators
    By loanAmount = By.id("amount");
    By downPayment = By.id("downPayment");
    By fromAccount = By.id("fromAccountId");
    By applyNowButton = By.xpath("//input[@value='Apply Now']");
    By successMessage = By.xpath("//h1[contains(text(),'Loan Request Processed')]");

    public RequestLoanPage(WebDriver driver) {
        this.driver = driver;
    }

    
    public void enterLoanDetails(String loanAmt, String downPay) {
        driver.findElement(loanAmount).sendKeys(loanAmt);
        driver.findElement(downPayment).sendKeys(downPay);
    }

    public void clickApplyNow() {
        driver.findElement(applyNowButton).click();
    }

    public boolean isLoanProcessed() {
        try {
            return driver.findElement(successMessage).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }


	
}
