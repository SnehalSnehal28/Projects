package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class OpenNewAccountPage {

    WebDriver driver;

    // --- Locators ---
    By openNewAccountLink = By.linkText("Open New Account");
    By accountTypeDropdown = By.id("type");
    By fromAccountDropdown = By.id("fromAccountId");
    By openNewAccountButton = By.xpath("//input[@value='Open New Account']");
    By confirmationMessage = By.xpath("//h1[contains(text(),'Account Opened!')]");
    By newAccountNumber = By.id("newAccountId");

    // --- Constructor ---
    public OpenNewAccountPage(WebDriver driver) {
        this.driver = driver;
    }

    // --- Actions ---
    public void clickOpenNewAccountLink() {
        driver.findElement(openNewAccountLink).click();
    }

    public void selectAccountType(String type) {
        Select dropdown = new Select(driver.findElement(accountTypeDropdown));
        dropdown.selectByVisibleText(type);
    }

    public void selectFromAccount(int index) {
        Select dropdown = new Select(driver.findElement(fromAccountDropdown));
        dropdown.selectByIndex(index);
    }

    public void clickOpenNewAccountButton() {
        driver.findElement(openNewAccountButton).click();
    }

    public boolean isAccountOpened() {
        try {
            return driver.findElement(confirmationMessage).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public String getNewAccountNumber() {
        return driver.findElement(newAccountNumber).getText();
    }
}
