package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class AccountHistoryPage {

    WebDriver driver;

    // Locator for transaction table after Account Details heading
    By transactionTable = By.xpath("//h1[text()='Account Details']/following::table[1]");

    public AccountHistoryPage(WebDriver driver) {
        this.driver = driver;
    }

    // Method to check if transaction table is visible
    public boolean isTransactionTableDisplayed() {
        try {
            System.out.println("Waiting for transaction history table...");
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.visibilityOfElementLocated(transactionTable));
            boolean visible = driver.findElement(transactionTable).isDisplayed();
            System.out.println("Transaction table visible: " + visible);
            return visible;
        } catch (Exception e) {
            System.out.println("Transaction table not found: " + e.getMessage());
            return false;
        }
    }
}
