package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BillPayPage {

    WebDriver driver;

    // --- Locators ---
    By billPayLink = By.linkText("Bill Pay");
    By payeeName = By.name("payee.name");
    By address = By.name("payee.address.street");
    By city = By.name("payee.address.city");
    By state = By.name("payee.address.state");
    By zipCode = By.name("payee.address.zipCode");
    By phone = By.name("payee.phoneNumber");
    By accountNumber = By.name("payee.accountNumber");
    By verifyAccount = By.name("verifyAccount");
    By amount = By.name("amount");
    By fromAccount = By.name("fromAccountId");
    By sendPaymentButton = By.xpath("//input[@value='Send Payment']");
    By confirmationMessage = By.xpath("//h1[contains(text(),'Bill Payment Complete')]");

    // --- Constructor ---
    public BillPayPage(WebDriver driver) {
        this.driver = driver;
    }

    // --- Actions ---
    public void clickBillPayLink() {
        driver.findElement(billPayLink).click();
    }

    public void fillPayeeDetails(String name, String addr, String cityName, String st, String zip,
                                 String ph, String acc, String amt) {
        driver.findElement(payeeName).sendKeys(name);
        driver.findElement(address).sendKeys(addr);
        driver.findElement(city).sendKeys(cityName);
        driver.findElement(state).sendKeys(st);
        driver.findElement(zipCode).sendKeys(zip);
        driver.findElement(phone).sendKeys(ph);
        driver.findElement(accountNumber).sendKeys(acc);
        driver.findElement(verifyAccount).sendKeys(acc);
        driver.findElement(amount).sendKeys(amt);
    }

    public void clickSendPayment() {
        driver.findElement(sendPaymentButton).click();
    }

    public boolean isPaymentSuccessful() {
        try {
            return driver.findElement(confirmationMessage).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
