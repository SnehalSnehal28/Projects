package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AccountOverviewPage {

    WebDriver driver;

    By accountTable = By.xpath("//table[@id='accountTable']");
    By totalBalance = By.xpath("//b[contains(text(),'Total')]");

    public AccountOverviewPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isAccountTableVisible() {
        try {
            return driver.findElement(accountTable).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isTotalBalanceDisplayed() {
        try {
            return driver.findElement(totalBalance).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
