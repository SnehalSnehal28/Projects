package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class TransferFundsPage {

    WebDriver driver;

    // --- Locators ---
    By transferFundsLink = By.linkText("Transfer Funds");
    By amountField = By.id("amount");
    By fromAccount = By.id("fromAccountId");
    By toAccount = By.id("toAccountId");
    By transferButton = By.xpath("//input[@value='Transfer']");
    By successMessage = By.xpath("//h1[contains(text(),'Transfer Complete!')]");

    // --- Constructor ---
    public TransferFundsPage(WebDriver driver) {
        this.driver = driver;
    }

    // --- Actions ---
    public void clickTransferFundsLink() {
        driver.findElement(transferFundsLink).click();
    }

    public void enterAmount(String amount) {
        driver.findElement(amountField).sendKeys(amount);
    }

    public void clickTransferButton() {
        driver.findElement(transferButton).click();
    }

    public boolean isTransferSuccessful() {
        try {
            return driver.findElement(successMessage).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
