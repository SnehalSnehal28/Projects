package pages;

import base.BaseTest;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;

public class HomePage extends BaseTest {

    @Test
    public void verifyHomePageLinks() throws InterruptedException {

        // Step 1: Login
        LoginPage login = new LoginPage(driver);
        login.enterUsername("snehal123");
        login.enterPassword("Snehal@123");
        login.clickLogin();
        Thread.sleep(2000);

        // Step 2: Verify important links
        Assert.assertTrue(driver.findElement(By.linkText("Accounts Overview")).isDisplayed(), "Accounts Overview not visible");
        Assert.assertTrue(driver.findElement(By.linkText("Transfer Funds")).isDisplayed(), "Transfer Funds not visible");
        Assert.assertTrue(driver.findElement(By.linkText("Bill Pay")).isDisplayed(), " Bill Pay not visible");
        Assert.assertTrue(driver.findElement(By.linkText("Request Loan")).isDisplayed(), " Request Loan not visible");

        System.out.println("All main links visible on Home Page!");
    }
}
